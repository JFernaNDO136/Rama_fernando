SELECT * FROM empleados;

SELECT nombre, nombre2, apellido, apellido2, email FROM empleados;

SELECT nombre, apellido FROM empleados WHERE id_departamento = 1;

SELECT nombre, apellido FROM empleados WHERE id_departamento = 1 AND sexo = 'Femenino';

SELECT nombre, apellido FROM empleados WHERE id_departamento = 1 OR id_departamento = 3;

SELECT nombre, apellido FROM empleados WHERE apellido LIKE 'M%';

SELECT nombre, apellido, fecha_contratacion FROM empleados WHERE fecha_contratacion BETWEEN '2020-01-01' AND '2022-12-31';

SELECT nombre_cargo, salario FROM cargos WHERE salario > 4000;

SELECT nombre, apellido, fecha_nacimiento FROM empleados WHERE fecha_nacimiento > '1990-12-31';

SELECT nombre, apellido FROM empleados WHERE nombre = 'Maria' AND sexo = 'Femenino';