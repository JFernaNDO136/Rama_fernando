INSERT INTO departamentos (nombre, fecha_creacion) VALUES
('Tecnología', '2020-01-15'),
('Recursos Humanos', '2020-01-15'),
('Ventas', '2020-02-01'),
('Contabilidad', '2020-02-01'),
('Logística', '2020-03-01');

INSERT INTO cargos (nombre_cargo, salario) VALUES
('Desarrollador Junior', 2800.00),
('Desarrollador Senior', 5500.00),
('Analista', 4500.00),
('Gerente', 7000.00),
('Reclutador', 3200.00),
('Contador', 4000.00),
('Vendedor', 3000.00);

INSERT INTO empleados (cedula, nombre, nombre2, apellido, apellido2, fecha_nacimiento, sexo, email, telefono, fecha_contratacion, id_departamento, id_cargo) VALUES
('1001', 'Maria', NULL, 'Gonzalez', 'Perez', '1990-05-15', 'Femenino', 'maria@empresa.com', '3001111111', '2020-03-10', 1, 2),
('1002', 'Carlos', 'Alberto', 'Rodriguez', NULL, '1985-08-22', 'Masculino', 'carlos@empresa.com', '3002222222', '2019-11-15', 1, 4),
('1003', 'Ana', 'Maria', 'Martinez', NULL, '1992-12-03', 'Femenino', 'ana@empresa.com', '3003333333', '2021-01-20', 1, 1),
('1004', 'Luis', NULL, 'Hernandez', 'Garcia', '1988-07-18', 'Masculino', 'luis@empresa.com', '3004444444', '2020-06-05', 1, 3),
('1005', 'Laura', NULL, 'Diaz', 'Lopez', '1993-04-25', 'Femenino', 'laura@empresa.com', '3005555555', '2022-02-14', 1, 1),
('1006', 'Pedro', 'Jose', 'Lopez', NULL, '1987-09-30', 'Masculino', 'pedro@empresa.com', '3006666666', '2021-08-22', 2, 5),
('1007', 'Sofia', NULL, 'Ramirez', 'Mendez', '1991-11-08', 'Femenino', 'sofia@empresa.com', '3007777777', '2020-09-10', 2, 5),
('1008', 'Diego', 'Fernando', 'Castillo', NULL, '1989-03-12', 'Masculino', 'diego@empresa.com', '3008888888', '2021-03-18', 3, 7),
('1009', 'Elena', NULL, 'Morales', 'Silva', '1994-06-20', 'Femenino', 'elena@empresa.com', '3009999999', '2022-05-30', 3, 7),
('1010', 'Javier', NULL, 'Rojas', 'Castro', '1986-01-14', 'Masculino', 'javier@empresa.com', '3011111111', '2019-12-01', 4, 6),
('1011', 'Carmen', 'Isabel', 'Vargas', NULL, '1990-10-05', 'Femenino', 'carmen@empresa.com', '3012222222', '2020-07-12', 4, 6),
('1012', 'Ricardo', NULL, 'Silva', 'Ortega', '1984-02-28', 'Masculino', 'ricardo@empresa.com', '3013333333', '2021-11-25', 5, 6),
('1013', 'Patricia', 'Andrea', 'Castro', NULL, '1995-08-17', 'Femenino', 'patricia@empresa.com', '3014444444', '2023-01-08', 1, 1),
('1014', 'Fernando', NULL, 'Mendoza', 'Rios', '1983-12-22', 'Masculino', 'fernando@empresa.com', '3015555555', '2020-04-15', 2, 5),
('1015', 'Gabriela', NULL, 'Ortega', 'Navarro', '1992-07-11', 'Femenino', 'gabriela@empresa.com', '3016666666', '2021-09-05', 3, 7),
('1016', 'Raul', 'Antonio', 'Guerrero', NULL, '1989-04-03', 'Masculino', 'raul@empresa.com', '3017777777', '2022-03-20', 1, 3),
('1017', 'Isabel', NULL, 'Navarro', 'Flores', '1991-09-14', 'Femenino', 'isabel@empresa.com', '3018888888', '2020-10-30', 4, 6),
('1018', 'Oscar', 'David', 'Santos', NULL, '1987-05-09', 'Masculino', 'oscar@empresa.com', '3019999999', '2021-06-12', 5, 6),
('1019', 'Teresa', NULL, 'Delgado', 'Herrera', '1993-11-26', 'Femenino', 'teresa@empresa.com', '3021111111', '2022-08-18', 1, 1),
('1020', 'Mario', NULL, 'Peña', 'Medina', '1985-06-08', 'Masculino', 'mario@empresa.com', '3022222222', '2019-07-22', 2, 5),
('1021', 'Rosa', 'Elena', 'Rios', NULL, '1994-03-19', 'Femenino', 'rosa@empresa.com', '3023333333', '2023-02-14', 3, 7),
('1022', 'Alberto', NULL, 'Flores', 'Cortes', '1988-10-07', 'Masculino', 'alberto@empresa.com', '3024444444', '2020-12-10', 4, 6),
('1023', 'Silvia', 'Patricia', 'Herrera', NULL, '1990-01-29', 'Femenino', 'silvia@empresa.com', '3025555555', '2021-04-25', 5, 6),
('1024', 'Roberto', NULL, 'Medina', 'Paredes', '1986-08-13', 'Masculino', 'roberto@empresa.com', '3026666666', '2022-07-08', 1, 2),
('1025', 'Natalia', NULL, 'Cortes', 'Vega', '1995-12-05', 'Femenino', 'natalia@empresa.com', '3027777777', '2023-03-01', 2, 5);

INSERT INTO proyectos (nombre_proyecto, fecha_inicio, fecha_fin) VALUES
('Sistema de Nomina', '2023-01-15', '2023-06-30'),
('Portal Web Clientes', '2023-02-01', '2023-08-15'),
('App Movil Ventas', '2023-03-10', '2023-09-20'),
('Migracion a la Nube', '2023-04-05', '2023-10-25'),
('Campaña Marketing', '2023-05-20', '2023-11-30');

INSERT INTO empleados_proyectos (id_empleado, id_proyecto, horas_trabajadas) VALUES
(1, 1, 120),
(2, 1, 80),
(3, 2, 160),
(4, 2, 140),
(5, 3, 200),
(6, 4, 90),
(7, 4, 110),
(8, 5, 180),
(9, 5, 150),
(10, 1, 70),
(11, 2, 130),
(12, 3, 95),
(13, 4, 165),
(14, 5, 120),
(15, 1, 85);